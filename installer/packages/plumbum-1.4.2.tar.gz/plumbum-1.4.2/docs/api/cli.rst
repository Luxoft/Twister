Package plumbum.cli
===================
.. automodule:: plumbum.cli.application
   :members:

.. automodule:: plumbum.cli.switches
   :members:

.. automodule:: plumbum.cli.terminal
   :members:
