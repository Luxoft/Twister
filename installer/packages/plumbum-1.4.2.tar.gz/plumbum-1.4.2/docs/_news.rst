* **2014.05.10**: Version 1.4.2 released. This is a maintenance release with mostly minor bug fixes, mostly revolving
  around Paramiko/Python 3 integration.

* **2014.02.28**: Version 1.4.1 released. This is a maintenance release with mostly minor bug fixes and some new
  features to the Path class.

* **2013.11.09**: Version 1.4 released, containing mostly bugfixes and some additions to the ``plumbum.cli.terminal``
  module

  .. note:: ``plumbum.utils`` became ``plumbum.path.utils``
