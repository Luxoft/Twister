version = (1, 4, 2)
version_string = "1.4.2"
release_date = "2014.05.10"
