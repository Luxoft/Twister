plumbum.local_machine
=====================
.. automodule:: plumbum.local_machine
   :members:
   :special-members:

