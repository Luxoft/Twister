plumbum.cli
===========
.. automodule:: plumbum.cli
   :members:
