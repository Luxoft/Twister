plumbum.commands
================
.. automodule:: plumbum.commands
   :members:
   :special-members:
