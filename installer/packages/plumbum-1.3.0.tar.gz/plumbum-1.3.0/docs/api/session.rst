plumbum.session
===============
.. automodule:: plumbum.session
   :members:
