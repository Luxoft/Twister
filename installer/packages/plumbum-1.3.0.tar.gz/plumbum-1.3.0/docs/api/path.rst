plumbum.path
------------
.. automodule:: plumbum.path
   :members:
   :special-members:
