plumbum.remote_machine
======================
.. automodule:: plumbum.remote_machine
   :members:
   :special-members:

plumbum.paramiko_machine
========================
.. automodule:: plumbum.paramiko_machine
   :members:
   :special-members:

