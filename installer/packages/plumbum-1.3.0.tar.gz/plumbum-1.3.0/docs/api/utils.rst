plumbum.utils
=============
.. automodule:: plumbum.utils
   :members:
