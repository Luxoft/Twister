* **2013.06.06**: Version 1.2 released; lots of bug fixes, compatibiltiy issues, and some small but useful 
  new features 

* **2012.12.14**: Version 1.1 released; adds :ref:`Paramiko integration <guide-paramiko-machine>` 
  and :ref:`subcommand support <guide-subcommands>`

* **2012.10.20**: Version 1.0.1 released; fixes bugs and adds :ref:`PuttyMachine <remote-machines>`
