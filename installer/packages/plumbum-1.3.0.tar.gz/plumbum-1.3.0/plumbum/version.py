version = (1, 3, 0)
version_string = "1.3.0"
release_date = "2013.08.25"
