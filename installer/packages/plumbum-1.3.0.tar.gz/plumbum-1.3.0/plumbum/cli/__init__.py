from plumbum.cli.switches import SwitchError, switch, autoswitch, SwitchAttr, Flag, CountOf
from plumbum.cli.switches import Range, Set, ExistingDirectory, ExistingFile, NonexistentPath, Predicate
from plumbum.cli.application import Application
