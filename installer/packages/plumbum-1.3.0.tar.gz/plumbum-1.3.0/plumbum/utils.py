#
# Provided for backward-compatibility with Plumbum 1.2; will be removed in the future
#
from plumbum.path.utils import delete, copy, move

