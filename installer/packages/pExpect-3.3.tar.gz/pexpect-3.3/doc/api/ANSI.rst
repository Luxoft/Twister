ANSI - ANSI (VT100) terminal emulator
=====================================

.. automodule:: pexpect.ANSI

.. autoclass:: term
   :show-inheritance:

.. autoclass:: ANSI
   :show-inheritance:

   .. automethod:: write_ch
   .. automethod:: write
   .. automethod:: process