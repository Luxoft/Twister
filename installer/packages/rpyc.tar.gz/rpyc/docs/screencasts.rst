.. _screencasts:

Screen Casts
============

Part 1: Introduction to RPyC and the Classic Mode
-------------------------------------------------

.. raw:: html
   
   <object width="425" height="344" id="_741" data="http://showmedo.com/static/flowplayer/flowplayer-3.1.5.swf" type="application/x-shockwave-flash"><param name="movie" value="http://showmedo.com/static/flowplayer/flowplayer-3.1.5.swf" />
   <param name="allowfullscreen" value="true" />
   <param name="allowscriptaccess" value="always" />
   <param name="flashvars" value='config={&quot;key&quot;:&quot;#$824e5316466b69d76dc&quot;,&quot;logo&quot;:{&quot;url&quot;:&quot;http://showmedo.com/static/images/showmedo_logo_vp.png&quot;,&quot;fullscreenOnly&quot;:false,&quot;top&quot;:20,&quot;right&quot;:20,&quot;opacity&quot;:0.5,&quot;displayTime&quot;:0,&quot;linkUrl&quot;:&quot;http://showmedo.com&quot;},&quot;clip&quot;:{&quot;baseUrl&quot;:&quot;http://showmedo.com&quot;,&quot;autoPlay&quot;:false,&quot;autoBuffering&quot;:true},&quot;playlist&quot;:[{&quot;url&quot;:&quot;http://videos1.showmedo.com/ShowMeDos/2780000.flv&quot;,&quot;title&quot;:&quot;Introduction to RPyC 3.0&quot;,&quot;baseUrl&quot;:&quot;http://showmedo.com&quot;,&quot;autoPlay&quot;:false,&quot;autoBuffering&quot;:true}],&quot;plugins&quot;:{&quot;controls&quot;:{&quot;url&quot;:&quot;http://showmedo.com/static/flowplayer/flowplayer.controls-3.1.5.swf&quot;,&quot;playlist&quot;:true}}}' />
   </object>

* `Link <http://showmedo.com/videotutorials/video?name=2780000;fromSeriesID=278>`_


Part 2: Services
----------------
N/A

Part 3: Callbacks
-----------------
N/A

