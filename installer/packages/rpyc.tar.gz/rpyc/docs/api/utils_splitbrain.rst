.. _api-splitbrain:

Splitbrain Python
=================

.. automodule:: rpyc.utils.splitbrain
   :members:
