====
Blog
====

.. blog-posts directive gets replaced with an ordered list of blog posts.

.. blog-posts::


.. The following toctree ensures blog posts get processed.

.. toctree::
    :hidden:
    :glob:

    blog/*
