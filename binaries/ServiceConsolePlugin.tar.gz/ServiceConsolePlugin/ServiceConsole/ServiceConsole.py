
from BasePlugin import BasePlugin

#

class Plugin(BasePlugin):
    pass

#
