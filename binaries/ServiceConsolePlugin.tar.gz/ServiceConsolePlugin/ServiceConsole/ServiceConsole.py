
from BasePlugin import BasePlugin

# version: 2.001

#

class Plugin(BasePlugin):
    pass

#
