oft_config={
'controller':{'host':'127.0.0.1','port': 6633},
'port_map':{1: 'veth1', 2: 'veth3', 3: 'veth5', 4: 'veth7'}
}


